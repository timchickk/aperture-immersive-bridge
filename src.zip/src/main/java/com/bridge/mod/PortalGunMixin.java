package com.bridge.mod;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "com.github.aperture.items.PortalGunItem") 
public class PortalGunMixin {

    @Inject(method = "shootPortal", at = @At("HEAD"), cancellable = true)
    private void onShootPortal(Level level, Player player, ItemStack stack, BlockPos pos, Direction face, CallbackInfo ci) {
        if (!level.isClientSide) {
            // Код отменяет старый портал и готовит место для Immersive Portals
            ci.cancel(); 
        }
    }
}